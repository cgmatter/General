# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "CGMatter Nodes",
    "author" : "CGMatter", 
    "description" : "CGMatter Node Library",
    "blender" : (4, 4, 0),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os
import os, base64, requests




def string_to_int(value):
    if value.isdigit():
        return int(value)
    return 0


def string_to_icon(value):
    if value in bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.keys():
        return bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items[value].value
    return string_to_int(value)


addon_keymaps = {}
_icons = None


def load_preview_icon(path):
    global _icons
    if not path in _icons:
        if os.path.exists(path):
            _icons.load(path, path, "IMAGE")
        else:
            return 0
    return _icons[path].icon_id


class SNA_AddonPreferences_403CA(bpy.types.AddonPreferences):
    bl_idname = __package__

    def draw(self, context):
        if not (False):
            layout = self.layout 
            box_D10E3 = layout.box()
            box_D10E3.alert = False
            box_D10E3.enabled = True
            box_D10E3.active = True
            box_D10E3.use_property_split = False
            box_D10E3.use_property_decorate = False
            box_D10E3.alignment = 'Expand'.upper()
            box_D10E3.scale_x = 1.0
            box_D10E3.scale_y = 1.0
            if not True: box_D10E3.operator_context = "EXEC_DEFAULT"
            split_6A52D = box_D10E3.split(factor=0.31249967217445374, align=True)
            split_6A52D.alert = False
            split_6A52D.enabled = True
            split_6A52D.active = True
            split_6A52D.use_property_split = False
            split_6A52D.use_property_decorate = False
            split_6A52D.scale_x = 1.0
            split_6A52D.scale_y = 1.0
            split_6A52D.alignment = 'Expand'.upper()
            if not True: split_6A52D.operator_context = "EXEC_DEFAULT"
            split_6A52D.template_icon(icon_value=load_preview_icon(os.path.join(os.path.dirname(__file__), 'assets', 'CGMatter_Icon.png')), scale=6.0)
            col_3621C = split_6A52D.column(heading='', align=True)
            col_3621C.alert = False
            col_3621C.enabled = True
            col_3621C.active = True
            col_3621C.use_property_split = False
            col_3621C.use_property_decorate = False
            col_3621C.scale_x = 1.0
            col_3621C.scale_y = 2.0
            col_3621C.alignment = 'Expand'.upper()
            col_3621C.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_3621C.separator(factor=0.9249999523162842)
            col_3621C.label(text='Nodes available to all CGMatter.com members!', icon_value=0)
            box_5A47B = col_3621C.box()
            box_5A47B.alert = False
            box_5A47B.enabled = True
            box_5A47B.active = True
            box_5A47B.use_property_split = False
            box_5A47B.use_property_decorate = False
            box_5A47B.alignment = 'Expand'.upper()
            box_5A47B.scale_x = 1.0
            box_5A47B.scale_y = 1.0
            if not True: box_5A47B.operator_context = "EXEC_DEFAULT"
            op = box_5A47B.operator('sna.cgmattercom_8163d', text='Unlock at CGMatter.com', icon_value=string_to_icon('INTERNET'), emboss=True, depress=False)
            box_6B1E4 = layout.box()
            box_6B1E4.alert = False
            box_6B1E4.enabled = True
            box_6B1E4.active = True
            box_6B1E4.use_property_split = False
            box_6B1E4.use_property_decorate = False
            box_6B1E4.alignment = 'Expand'.upper()
            box_6B1E4.scale_x = 1.0
            box_6B1E4.scale_y = 1.0
            if not True: box_6B1E4.operator_context = "EXEC_DEFAULT"
            box_6B1E4.label(text='Choose an asset path (nodes will download/update into this folder).', icon_value=0)
            split_4AFE5 = box_6B1E4.split(factor=0.1416667103767395, align=True)
            split_4AFE5.alert = False
            split_4AFE5.enabled = True
            split_4AFE5.active = True
            split_4AFE5.use_property_split = False
            split_4AFE5.use_property_decorate = False
            split_4AFE5.scale_x = 1.0
            split_4AFE5.scale_y = 1.0
            split_4AFE5.alignment = 'Expand'.upper()
            if not True: split_4AFE5.operator_context = "EXEC_DEFAULT"
            split_4AFE5.label(text='Asset Path:', icon_value=0)
            col_AB514 = split_4AFE5.column(heading='', align=False)
            col_AB514.alert = (bpy.context.scene.sna_path == '')
            col_AB514.enabled = True
            col_AB514.active = True
            col_AB514.use_property_split = False
            col_AB514.use_property_decorate = False
            col_AB514.scale_x = 1.0
            col_AB514.scale_y = 1.0
            col_AB514.alignment = 'Expand'.upper()
            col_AB514.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_AB514.prop(bpy.context.scene, 'sna_path', text='', icon_value=string_to_icon('ASSET_MANAGER'), emboss=True)
            box_6B1E4.label(text='Enter the password and then download/update (requires internet access).', icon_value=0)
            split_0D38A = box_6B1E4.split(factor=0.6375000476837158, align=True)
            split_0D38A.alert = False
            split_0D38A.enabled = True
            split_0D38A.active = True
            split_0D38A.use_property_split = False
            split_0D38A.use_property_decorate = False
            split_0D38A.scale_x = 1.0
            split_0D38A.scale_y = 1.0
            split_0D38A.alignment = 'Expand'.upper()
            if not True: split_0D38A.operator_context = "EXEC_DEFAULT"
            split_0D38A.prop(bpy.context.scene, 'sna_token', text='Password', icon_value=string_to_icon('KEYINGSET'), emboss=True)
            op = split_0D38A.operator('sna.download_cgmatter_nodes_928bc', text='Download/Update', icon_value=string_to_icon('INTERNET'), emboss=True, depress=False)


class SNA_OT_Download_Cgmatter_Nodes_928Bc(bpy.types.Operator):
    bl_idname = "sna.download_cgmatter_nodes_928bc"
    bl_label = "Download CGMatter Nodes"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        token = bpy.context.scene.sna_token
        folder = bpy.context.scene.sna_path
        owner = "cgmatter"
        repo = "Nodes"
        branch = "main"
        file_paths = [
            "Nodes/CGMatter_Nodes.blend",
            "Nodes/blender_assets.cats.txt",
            "Nodes/blender_assets.cats.txt~"
        ]
        os.makedirs(folder, exist_ok=True)
        h = {"Authorization": f"Bearer {token}"}
        t = requests.get(f"https://api.github.com/repos/{owner}/{repo}/branches/{branch}", headers=h).json()["commit"]["sha"]
        tree = requests.get(f"https://api.github.com/repos/{owner}/{repo}/git/trees/{t}?recursive=1", headers=h).json()["tree"]
        for path in file_paths:
            b = next(i["sha"] for i in tree if i["path"] == path)
            c = base64.b64decode(requests.get(f"https://api.github.com/repos/{owner}/{repo}/git/blobs/{b}", headers=h).json()["content"])
            with open(os.path.join(folder, os.path.basename(path)), "wb") as f: f.write(c)
        bpy.ops.preferences.asset_library_add(directory=bpy.context.scene.sna_path)
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.label(text='Make sure you have internet access enabled.', icon_value=0)
        layout.label(text='Download includes 3 files (.blend, and 2 catalog .txt files)', icon_value=0)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_Cgmattercom_8163D(bpy.types.Operator):
    bl_idname = "sna.cgmattercom_8163d"
    bl_label = "CGMatter.com"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        exec('import webbrowser; webbrowser.open("https://www.cgmatter.com/nodes")')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_path = bpy.props.StringProperty(name='Path', description='', default='', subtype='DIR_PATH', maxlen=0)
    bpy.types.Scene.sna_token = bpy.props.StringProperty(name='Token', description='', default='', subtype='PASSWORD', maxlen=0)
    bpy.utils.register_class(SNA_AddonPreferences_403CA)
    bpy.utils.register_class(SNA_OT_Download_Cgmatter_Nodes_928Bc)
    bpy.utils.register_class(SNA_OT_Cgmattercom_8163D)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_token
    del bpy.types.Scene.sna_path
    bpy.utils.unregister_class(SNA_AddonPreferences_403CA)
    bpy.utils.unregister_class(SNA_OT_Download_Cgmatter_Nodes_928Bc)
    bpy.utils.unregister_class(SNA_OT_Cgmattercom_8163D)
